package com.example.marvelwiki

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
