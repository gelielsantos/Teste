import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:marvelwiki/lista.dart';

class Inicio extends StatelessWidget {
  const Inicio({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFED1D24),
      body: ListView(
        children: [
          Image.asset(
            "imagens/entradalogo.png",
            fit: BoxFit.cover,
          ),
          Center(
            child: Padding(padding: EdgeInsets.only(top: 40),
              child: Text(
              "Bem-Vindo ao maior Wiki Fandom",
              style: TextStyle(
                color: Color(0xFFED1D24),
                fontSize: 30,
                backgroundColor: Colors.white,
              ),
            ),
          ),
    ),
          Padding(
            padding: EdgeInsets.only(top: 20, bottom: 32),
            child: Center(
              child: Text(
                "Pesquise sobre seus heróis... Mas nunca conheça eles...",
                style: TextStyle(
                  color: Color(0xFFED1D24),
                  fontSize: 15,
                  backgroundColor: Colors.white,
                ),
              ),
            ),
          ),
          Padding(padding: EdgeInsets.only(right: 200, left: 200),
            child: Image.asset(
              "imagens/entradavigia.png",
            ),
          ),

          Padding(padding: EdgeInsets.all(32)),
          Center(
              child: ElevatedButton.icon(
                onPressed: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (context) => Lista()));
                },
                style: ElevatedButton.styleFrom(
                  primary: Colors.white,
                  elevation: 20,
                  shadowColor: Colors.black,
                ),
                icon: Icon(Icons.search, color: Color(0xFFED1D24),),
                label: Text('Faça sua escolha', style: TextStyle(color: Color(0xFFED1D24),),),
              ))
        ],
      ),
    );
  }
}
